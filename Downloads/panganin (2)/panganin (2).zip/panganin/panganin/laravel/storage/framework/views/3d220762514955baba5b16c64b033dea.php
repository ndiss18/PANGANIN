

<?php $__env->startSection('title', $menu->nama_menu.' | Panganin'); ?>

<?php $__env->startSection('content'); ?>
  <article class="checkout-box" style="max-width: 760px; margin: 0 auto;">
    <img src="<?php echo e($menu->gambar); ?>" alt="<?php echo e($menu->nama_menu); ?>" style="width: 100%; max-height: 360px; object-fit: cover; border-radius: 16px;">
    <p class="section-tag"><?php echo e($menu->kategori); ?></p>
    <h1 class="box-title"><?php echo e($menu->nama_menu); ?></h1>
    <p><?php echo e($menu->deskripsi); ?></p>
    <p class="total-price">Rp<?php echo e(number_format($menu->harga, 0, ',', '.')); ?></p>
    <a class="btn btn-secondary btn-sm" href="<?php echo e(route('home')); ?>#menu">Kembali ke katalog</a>
  </article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\andis\Downloads\panganin\panganin\laravel\resources\views/menu/show.blade.php ENDPATH**/ ?>