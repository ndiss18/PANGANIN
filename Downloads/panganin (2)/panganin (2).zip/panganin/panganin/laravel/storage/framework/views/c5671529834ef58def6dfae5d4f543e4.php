

<?php $__env->startSection('title', 'Kelola Pesanan | Panganin'); ?>

<?php $__env->startSection('content'); ?>
  <div class="section-header">
    <span class="section-tag">Admin</span>
    <h1 class="section-title">Pesanan Pelanggan</h1>
    <p class="section-subtitle">Periksa rincian pesanan dan perbarui status pemrosesan.</p>
  </div>
  <div class="order-history-list">
    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <article class="order-history-card">
        <div class="order-card-header">
          <div>
            <h2 class="order-number"><?php echo e($order->nomor_pesanan); ?></h2>
            <p class="order-timestamp"><?php echo e($order->created_at->format('d M Y, H:i')); ?> · <?php echo e($order->nama_pelanggan); ?> · <?php echo e($order->lokasi_pengambilan); ?></p>
          </div>
          <span class="total-price">Rp<?php echo e(number_format($order->total_harga, 0, ',', '.')); ?></span>
        </div>
        <div class="order-details-box">
          <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="order-mini-item">
              <span class="order-mini-item-name"><?php echo e($detail->nama_menu); ?> <strong>x<?php echo e($detail->jumlah); ?></strong></span>
              <span class="order-mini-item-price">Rp<?php echo e(number_format($detail->subtotal, 0, ',', '.')); ?></span>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if($order->catatan): ?>
            <p class="order-notes-tag">Catatan: <?php echo e($order->catatan); ?></p>
          <?php endif; ?>
        </div>
        <form class="checkout-form" method="post" action="<?php echo e(route('admin.orders.status', $order)); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('patch'); ?>
          <div class="form-group">
            <label class="form-label" for="status-<?php echo e($order->id); ?>">Status pesanan</label>
            <select class="form-input" id="status-<?php echo e($order->id); ?>" name="status">
              <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status); ?>" <?php if($order->status === $status): echo 'selected'; endif; ?>><?php echo e(str_replace('_', ' ', ucfirst($status))); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <button class="btn btn-secondary btn-sm" type="submit">Perbarui Status</button>
        </form>
      </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p>Belum ada pesanan pelanggan.</p>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\andis\Downloads\panganin\panganin\laravel\resources\views/admin/orders.blade.php ENDPATH**/ ?>