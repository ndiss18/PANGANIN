

<?php $__env->startSection('title', $adminLogin ? 'Login Admin | Panganin' : 'Masuk | Panganin'); ?>

<?php $__env->startSection('content'); ?>
  <div class="section-header">
    <span class="section-tag"><?php echo e($adminLogin ? 'Pengelolaan Kantin' : 'Akun Panganin'); ?></span>
    <h1 class="section-title"><?php echo e($adminLogin ? 'Login Admin' : 'Masuk ke Panganin'); ?></h1>
    <p class="section-subtitle">Gunakan akun Panganin untuk menyimpan dan melihat pesanan.</p>
  </div>
  <section class="checkout-box" style="max-width: 560px; margin: 0 auto;">
    <form class="checkout-form" method="post" action="<?php echo e($adminLogin ? route('admin.login.submit') : route('login.submit')); ?>">
      <?php echo csrf_field(); ?>
      <?php if($errors->any()): ?>
        <div class="alert-box alert-danger" role="alert"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>
      <div class="form-group">
        <label class="form-label" for="email">Email</label>
        <input class="form-input" id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required>
      </div>
      <div class="form-group">
        <label class="form-label" for="password">Kata sandi</label>
        <input class="form-input" id="password" name="password" type="password" autocomplete="current-password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Masuk</button>
      <?php if (! ($adminLogin)): ?>
        <p class="form-hint">Belum punya akun? <a href="<?php echo e(route('register')); ?>">Daftar akun pelanggan</a>.</p>
      <?php endif; ?>
    </form>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\andis\Downloads\panganin\panganin\laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>