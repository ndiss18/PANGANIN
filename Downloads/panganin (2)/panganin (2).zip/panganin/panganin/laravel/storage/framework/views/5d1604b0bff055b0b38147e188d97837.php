<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent('title', 'Panganin | Kantin Kampus Digital'); ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
  <header class="site-header">
    <div class="container header-container">
      <a href="<?php echo e(route('home')); ?>" class="brand">
        <span class="brand-name">Panganin</span>
        <span class="brand-tagline">Pesan makanan tanpa antre</span>
      </a>
      <nav class="site-nav" aria-label="Navigasi akun">
        <ul class="nav-list">
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>#menu">Menu</a></li>
          <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->role === 'admin'): ?>
              <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.menus')); ?>">Kelola Menu</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.orders')); ?>">Pesanan</a></li>
            <?php endif; ?>
            <li class="nav-item">
              <form action="<?php echo e(route('logout')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-text-danger">Keluar</button>
              </form>
            </li>
          <?php else: ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Masuk</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.login')); ?>">Login Admin</a></li>
          <?php endif; ?>
        </ul>
      </nav>
    </div>
  </header>
  <main class="cart-section">
    <div class="container">
      <?php if(session('status')): ?>
        <div class="alert-box" role="status"><?php echo e(session('status')); ?></div>
      <?php endif; ?>
      <?php echo $__env->yieldContent('content'); ?>
    </div>
  </main>
</body>
</html>
<?php /**PATH C:\Users\andis\Downloads\panganin\panganin\laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>