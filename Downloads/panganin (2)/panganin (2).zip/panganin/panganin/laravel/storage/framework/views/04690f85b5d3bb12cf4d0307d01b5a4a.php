

<?php $__env->startSection('title', 'Dashboard Admin | Panganin'); ?>

<?php $__env->startSection('content'); ?>
  <div class="section-header">
    <span class="section-tag">Admin</span>
    <h1 class="section-title">Dashboard Panganin</h1>
    <p class="section-subtitle">Kelola menu dan pesanan kantin dari satu tempat.</p>
  </div>
  <div class="order-history-list">
    <article class="order-history-card"><h2 class="box-title">Menu tersedia</h2><p class="total-price"><?php echo e($menuCount); ?></p></article>
    <article class="order-history-card"><h2 class="box-title">Pesanan tersimpan</h2><p class="total-price"><?php echo e($orderCount); ?></p></article>
    <article class="order-history-card"><h2 class="box-title">Menunggu diproses</h2><p class="total-price"><?php echo e($pendingCount); ?></p></article>
  </div>
  <p>
    <a class="btn btn-primary" href="<?php echo e(route('admin.menus')); ?>">Kelola Menu</a>
    <a class="btn btn-secondary" href="<?php echo e(route('admin.orders')); ?>">Kelola Pesanan</a>
  </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\andis\Downloads\panganin\panganin\laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>