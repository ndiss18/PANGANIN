

<?php $__env->startSection('title', 'Pesanan '.$order->nomor_pesanan.' | Panganin'); ?>

<?php $__env->startSection('content'); ?>
  <div class="section-header">
    <span class="section-tag">Rincian Pesanan</span>
    <h1 class="section-title"><?php echo e($order->nomor_pesanan); ?></h1>
    <p class="section-subtitle">Status: <?php echo e(str_replace('_', ' ', ucfirst($order->status))); ?></p>
  </div>
  <article class="order-history-card">
    <p>Pemesan: <strong><?php echo e($order->nama_pelanggan); ?></strong></p>
    <p>Lokasi pengambilan: <?php echo e($order->lokasi_pengambilan); ?></p>
    <?php if($order->catatan): ?><p>Catatan: <?php echo e($order->catatan); ?></p><?php endif; ?>
    <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="order-mini-item">
        <span class="order-mini-item-name"><?php echo e($detail->nama_menu); ?> x<?php echo e($detail->jumlah); ?></span>
        <span class="order-mini-item-price">Rp<?php echo e(number_format($detail->subtotal, 0, ',', '.')); ?></span>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <p class="total-price">Total: Rp<?php echo e(number_format($order->total_harga, 0, ',', '.')); ?></p>
  </article>
  <a class="btn btn-secondary btn-sm" href="<?php echo e(route('home')); ?>#riwayat-pesanan">Kembali ke riwayat</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\andis\Downloads\panganin\panganin\laravel\resources\views/orders/show.blade.php ENDPATH**/ ?>