

<?php $__env->startSection('title', 'Kelola Menu | Panganin'); ?>

<?php $__env->startSection('content'); ?>
  <div class="section-header">
    <span class="section-tag">Admin</span>
    <h1 class="section-title">Kelola Menu Kantin</h1>
    <p class="section-subtitle">Tambah, perbarui, atau hapus menu di katalog Panganin.</p>
  </div>
  <section class="checkout-box" style="margin-bottom: 32px;">
    <h2 class="box-title"><?php echo e($editingMenu ? 'Edit Menu' : 'Tambah Menu'); ?></h2>
    <form class="checkout-form" method="post" action="<?php echo e($editingMenu ? route('admin.menus.update', $editingMenu) : route('admin.menus.store')); ?>">
      <?php echo csrf_field(); ?>
      <?php if($editingMenu): ?>
        <?php echo method_field('put'); ?>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="alert-box alert-danger" role="alert"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>
      <div class="form-group">
        <label class="form-label" for="nama_menu">Nama menu</label>
        <input class="form-input" id="nama_menu" name="nama_menu" maxlength="150" value="<?php echo e(old('nama_menu', $editingMenu?->nama_menu)); ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label" for="kategori">Kategori</label>
        <input class="form-input" id="kategori" name="kategori" list="menu-categories" maxlength="100" value="<?php echo e(old('kategori', $editingMenu?->kategori)); ?>" required>
        <datalist id="menu-categories"><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($category); ?>"><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></datalist>
      </div>
      <div class="form-group">
        <label class="form-label" for="harga">Harga (rupiah)</label>
        <input class="form-input" id="harga" name="harga" type="number" min="1" value="<?php echo e(old('harga', $editingMenu?->harga)); ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label" for="gambar">URL gambar (HTTPS)</label>
        <input class="form-input" id="gambar" name="gambar" type="url" maxlength="2048" value="<?php echo e(old('gambar', $editingMenu?->gambar)); ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label" for="deskripsi">Deskripsi</label>
        <textarea class="form-input form-textarea" id="deskripsi" name="deskripsi" rows="3" maxlength="2000" required><?php echo e(old('deskripsi', $editingMenu?->deskripsi)); ?></textarea>
      </div>
      <button type="submit" class="btn btn-primary"><?php echo e($editingMenu ? 'Simpan Perubahan' : 'Tambah Menu'); ?></button>
      <?php if($editingMenu): ?>
        <a class="btn btn-secondary btn-sm" href="<?php echo e(route('admin.menus')); ?>">Batal</a>
      <?php endif; ?>
    </form>
  </section>
  <div class="order-history-list">
    <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <article class="order-history-card">
        <div class="order-card-header">
          <div>
            <h2 class="order-number"><?php echo e($menu->nama_menu); ?></h2>
            <p class="order-timestamp"><?php echo e($menu->kategori); ?></p>
          </div>
          <span class="total-price">Rp<?php echo e(number_format($menu->harga, 0, ',', '.')); ?></span>
        </div>
        <p><?php echo e($menu->deskripsi); ?></p>
        <div class="order-history-actions">
          <a class="btn btn-secondary btn-sm" href="<?php echo e(route('admin.menus', ['edit' => $menu->id])); ?>">Edit</a>
          <form method="post" action="<?php echo e(route('admin.menus.delete', $menu)); ?>" onsubmit="return confirm('Hapus menu ini?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn-text-danger">Hapus</button>
          </form>
        </div>
      </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p>Belum ada menu di database.</p>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\andis\Downloads\panganin\panganin\laravel\resources\views/admin/menus.blade.php ENDPATH**/ ?>