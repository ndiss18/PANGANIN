

<?php $__env->startSection('title', 'Daftar | Panganin'); ?>

<?php $__env->startSection('content'); ?>
  <div class="section-header">
    <span class="section-tag">Akun Panganin</span>
    <h1 class="section-title">Daftar Akun</h1>
    <p class="section-subtitle">Buat akun pelanggan untuk memesan dan melihat riwayat pesanan.</p>
  </div>
  <section class="checkout-box" style="max-width: 560px; margin: 0 auto;">
    <form class="checkout-form" method="post" action="<?php echo e(route('register.store')); ?>">
      <?php echo csrf_field(); ?>
      <?php if($errors->any()): ?>
        <div class="alert-box alert-danger" role="alert"><?php echo e($errors->first()); ?></div>
      <?php endif; ?>
      <div class="form-group">
        <label class="form-label" for="nama">Nama</label>
        <input class="form-input" id="nama" name="nama" value="<?php echo e(old('nama')); ?>" autocomplete="name" maxlength="120" required>
      </div>
      <div class="form-group">
        <label class="form-label" for="email">Email</label>
        <input class="form-input" id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required>
      </div>
      <div class="form-group">
        <label class="form-label" for="password">Kata sandi</label>
        <input class="form-input" id="password" name="password" type="password" autocomplete="new-password" required>
      </div>
      <div class="form-group">
        <label class="form-label" for="password_confirmation">Ulangi kata sandi</label>
        <input class="form-input" id="password_confirmation" name="password_confirmation" type="password" autocomplete="new-password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Daftar</button>
      <p class="form-hint">Sudah memiliki akun? <a href="<?php echo e(route('login')); ?>">Masuk</a>.</p>
    </form>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\andis\Downloads\panganin\panganin\laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>